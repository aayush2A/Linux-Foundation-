#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>

static int __init panic_init(void) {
    printk(KERN_ALERT "Triggering kernel panic now...\n");
    panic("Kernel Panic triggered by panic_module.\n");
    return 0;
}

static void __exit panic_exit(void) {
    printk(KERN_ALERT "Exiting panic_module (this won't be seen if panic occurs).\n");
}

module_init(panic_init);
module_exit(panic_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Aayush Amin");
MODULE_DESCRIPTION("Kernel Module to trigger panic for Linux Foundation Task 3");
