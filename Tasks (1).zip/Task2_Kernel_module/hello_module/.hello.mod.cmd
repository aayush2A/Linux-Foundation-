savedcmd_/home/aayush/hello_module/hello.mod := printf '%s\n'   hello.o | awk '!x[$$0]++ { print("/home/aayush/hello_module/"$$0) }' > /home/aayush/hello_module/hello.mod
