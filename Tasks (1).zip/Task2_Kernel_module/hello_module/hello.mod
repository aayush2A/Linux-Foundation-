/home/aayush/hello_module/hello.o
