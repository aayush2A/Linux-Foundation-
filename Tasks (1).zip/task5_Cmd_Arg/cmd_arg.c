#include <linux/init.h>
#include <linux/module.h>
#include <linux/kernel.h>

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Aayush Amin");
MODULE_DESCRIPTION("A simple Linux module with command-line arguments.");
MODULE_VERSION("1.0");

static char *name = "world";
static int repeat = 1;

// ✅ Correct permissions: 0444 (readable by all), or 0644 if you want user to write
module_param(name, charp, 0444);
MODULE_PARM_DESC(name, "Name to greet");

module_param(repeat, int, 0444);
MODULE_PARM_DESC(repeat, "Number of times to greet");

static int __init cmd_arg_init(void)
{
    int i;
    for (i = 0; i < repeat; i++) {
        printk(KERN_INFO "Hello, %s! [%d]\n", name, i + 1);
    }
    return 0;
}

static void __exit cmd_arg_exit(void)
{
    printk(KERN_INFO "Goodbye, %s!\n", name);
}

module_init(cmd_arg_init);
module_exit(cmd_arg_exit);

