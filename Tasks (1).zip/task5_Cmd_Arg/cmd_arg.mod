/home/aayush/task5_Cmd_Arg/cmd_arg.o
