savedcmd_/home/aayush/task5_Cmd_Arg/cmd_arg.mod := printf '%s\n'   cmd_arg.o | awk '!x[$$0]++ { print("/home/aayush/task5_Cmd_Arg/"$$0) }' > /home/aayush/task5_Cmd_Arg/cmd_arg.mod
